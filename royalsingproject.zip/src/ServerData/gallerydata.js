import royalsingimage1 from "../images/backimg.jpg";
import royalsingimage2 from "../images/plazaimg.jpg";
import royalsingimage3 from "../images/poster.jpg";
import royalsingimage4 from "../images/RBimg.jpg"

const Gallerydata = [
    { src: royalsingimage1 },
    { src: royalsingimage2 },
    { src: royalsingimage3 },
    { src: royalsingimage4 },
    { src: royalsingimage1 },
    { src: royalsingimage4 },
    { src: royalsingimage1 },
    { src: royalsingimage2 },
    { src: royalsingimage3 },
    { src: royalsingimage4 },
    // ... more image data
  ];

  export default Gallerydata;